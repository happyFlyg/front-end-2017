var express = require('express');
var express = express();

//vue
const Vue = require('vue')
const app = new Vue({
  template: `<div>Hello Vue</div>`
})
const renderer = require('vue-server-renderer').createRenderer({
  template: require('fs').readFileSync('./index.template.html', 'utf-8')
})


express.get('/', function (req, res) {
  const renderer = require('vue-server-renderer').createRenderer({
	  template: require('fs').readFileSync('./index.template.html', 'utf-8')
  })

  renderer.renderToString(app, (err, html) => {
	  //console.log(html) // 应用程序内容注入页面.
	  res.send(html);
  })
});



var server = express.listen(3000, function () {
  var host = server.address().address;
  var port = server.address().port;

  console.log('Example app listening at http://%s:%s', host, port);
});