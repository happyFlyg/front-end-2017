var express = require('express');
var app = express();


//vue
const vue = require('vue')
const main = new vue({
	template:`<div>Hello vue</div>`
})
//ssr
const renderer = require('vue-server-renderer').createRenderer({
	template:require('fs').readFileSync('./index.template.html','utf-8')
})

//插值模版
const context = {
  title: 'vue ssr',
  meta: `
    <meta name="keywords" content="vue,ssr">
    <meta name="author" content="wos">
  `
}

app.get('/', function (req, res) {
  // res.send('Hello World!');
  	renderer.renderToString(main, context,(err,html) => {
		if (err) throw err
		res.send(html);
	})
});








var server = app.listen(3000, function () {
  var host = server.address().address;
  var port = server.address().port;

  console.log('Example app listening at http://%s:%s', host, port);
});