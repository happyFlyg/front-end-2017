<?php
	$appid = 'wx67bb2dbb4b1a929b';
	$appsecret = '0c13ec91438f8000a16ab90345a5c00f';
	$loginUrl = 'http://huihuibeidanci.com/login_weixin/';
	$domain = '.huihuibeidanci.com'; //cookies作用域
?>